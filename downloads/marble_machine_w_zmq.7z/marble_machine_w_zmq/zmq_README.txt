1. start.bat set PYTHONPATH=%cd%\Python38;%cd%\Python38\DLLs;%cd%\Python38\Lib;%cd%\Python38\Lib\site-packages;C:\NX2027.3401_lite\NXBIN\python;C:\CoppeliaSimEdu_4.3.0_rev12\programming\zmqRemoteApi\clients\python
2. pip install pyzmq cbor
3. Modules - Connectivity - ZMQ rempte API server (runnint)