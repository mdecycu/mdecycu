from zmqRemoteApi import RemoteAPIClient

print('Program started')

client = RemoteAPIClient()
sim = client.getObject('sim')

# Run a simulation in asynchronous mode:
sim.startSimulation()

sensor = sim.getObject('./Finish')
count = 0
while True:
    (errorCode3, detectionState1, detectedPoint1, detectedObjectHandle1, detectedSurfaceNormalVector1) = sim.readProximitySensor(sensor)
    if errorCode3 == 1:
        if detectionState1:
            count += 1
            print("通過球總數:", count)